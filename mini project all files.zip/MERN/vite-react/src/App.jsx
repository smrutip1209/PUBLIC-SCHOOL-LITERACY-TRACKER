import { useState } from 'react'
import Home from "./components/Home"
import Login from "./components/Login"
import './App.css'

function App() {

  const [view, setView] = useState(true);
  const [data, setData] = useState([]);

  return (
    <>
      {view ? <Login changeView = {setView} changeData = {setData} /> : <Home changeView = {setView} data = {data[0]} name = {data[1]}/>}
    </>
  )
}

export default App
