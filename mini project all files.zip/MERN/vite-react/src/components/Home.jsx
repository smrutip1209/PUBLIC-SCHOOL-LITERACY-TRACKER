import { useState } from 'react'

function App(props) {
  console.log(props)
  const [values, setValues] = useState({
    "district": "",
    "mandal": "",
    "muncipality": "",
    "wardname": ""
  })

  const run = async() => {
    

    var res = await fetch(`http://localhost:3000/query`,{
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
          "district" : values.district,
          "mandal" : values.mandal,
          "muncipality" : values.muncipality,
          "wardname" : values.wardname,
          "require" : document.getElementsByName("gender")[0].value
      })
    })
    .then(res => res.json())
    .then(res => {
      document.getElementsByClassName("result")[0].innerHTML = res.res === null ? "Nill" : res.res
    })

}
  

  return (
    <>
      <button style={{position: "fixed", top: "1em", right: "1em"}} className='btn btn-warning' onClick={() => props.changeView(true)}>Logout</button>
      <h4 style={{position: "fixed", top: "1em", left: "50%", transform: "translate(-50%, 0)", color: "white"}}>Welcome {props.name}</h4>
      <form id="district-form" >
        <br />
        <br />
        <label style={{"margin": 0}} htmlFor="district">District:</label>
        <select className="form-select" id="district" name="district" onChange={(e) => {
            try {
              
              document.getElementById("mandal").value = "_"
              document.getElementById("muncipality").value = "_"
              document.getElementById("wardname").value = "_"
            } catch (error) {
              
            }
            setValues({...values, "district": e.target.value, "mandal": "", "muncipality": "", "wardname": ""})
          }}>
            <option value="_" disabled selected></option>
            {Object.keys(props.data).map((district, i) => {
              return <option key={i} value={district}>{district}</option>
            })}
        </select>
        <br />
        {console.log(values)}
        <label style={{"margin": 0}} htmlFor="mandal">Mandal:</label>
        <select className="form-select" id="mandal" name="mandal"  onChange={(e) => {
          try {
            
            document.getElementById("municipality").value = "_"
            document.getElementById("wardname").value = "_"
          } catch (error) {
            console.log(error)
          }
            setValues({...values, "mandal": e.target.value, "muncipality": "", "wardname": ""})
          }}>
            <option value="_" disabled selected></option>
            {values.district !== "" && Object.keys(props.data[values.district]).map((mandal, i) => {
              return <option key={i} value={mandal}>{mandal}</option>
            })}
        </select>
        <br />
        <label style={{"margin": 0}} htmlFor="municipality">Municipality:</label>
        <select className="form-select" id="municipality" name="municipality" onChange={(e) => {
          try {
            document.getElementById("wardname").value = "_"
            
          } catch (error) {
            
          }
            setValues({...values, "muncipality": e.target.value, "wardname": ""})
          }}>
            <option value="_" disabled selected></option>
            {values.district !== "" && values.mandal !== "" && Object.keys(props.data[values.district][values.mandal]).map((muncipality, i) => {
              return <option key={i} value={muncipality}>{muncipality}</option>
            })}
        </select>
        <br />
        <label style={{"margin": 0}} htmlFor="wardname">Ward Name:</label>
        <select className="form-select" id="wardname" name="wardname" onChange={(e) => {
            setValues({...values, "wardname": e.target.value})
          }}>
            <option value="_" disabled selected></option>   
            {values.district !== "" && values.mandal !== "" && values.muncipality !== "" && Object.keys(props.data[values.district][values.mandal][values.muncipality]).map((wardname, i) => {
              return <option key={i} value={wardname}>{wardname}</option>
            })}
        </select>
        <br />
        <label htmlFor="gender">Gender:</label>
        <select className="form-select" id="gender" name="gender">
            <option value="female">Female</option>
            <option value="male">Male</option>
            <option value="transgender">Transgender</option>
        </select>
        <br />

        <center>

            <button className="btn btn-primary" type="button" onClick={() => run()}>Get</button>
            <br />
            <br />
            <h5 style={{color:"white"}}>Response : <span className = "result">Nill</span></h5>
        </center>
    </form>
    </>
  )
}

export default App
