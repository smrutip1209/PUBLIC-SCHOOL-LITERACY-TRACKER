import { useState } from "react";

import "./Login.css";

const Login = (props) => {

    const [info, setInfo] = useState({
        "loginEmail": "",
        "loginPassword": "",
        "registrationName": "",
        "registrationEmail": "",
        "registrationPassword": ""
    });

    console.log(info)

    const login = async () => {
        fetch("http://localhost:3000/login", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
              },
            body: JSON.stringify({
                "email": info.loginEmail,
                "password": info.loginPassword
            })
        })
        .then(res => res.json())
        .then(res => {
            if(res.login){
                props.changeView(false);
                props.changeData([res.data, res.name]);
            }
            else{
                alert("Invalid User Name or Password");
                return;
            }    
        })
    }
    const register = async () => {
        fetch("http://localhost:3000/register", {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
              },
            body: JSON.stringify({
                "name": info.registrationName,
                "email": info.registrationEmail,
                "password": info.registrationPassword
            })
        })
        .then(res => res.json())
        .then(res => {
            if(res.res){
                alert("Registration Successful, Please Login!");
                var temp = document.getElementsByClassName("toggle")[0]
                temp.checked = !temp.checked
            }
            else alert("Registration Failed, Please Try Again!");
        })
    }

    return (
        <div className="wrapper">
            <div className="card-switch">
                <label className="switch" >
                <input type="checkbox" className="toggle" />
                <span className="slider"></span>
                <span className="card-side"></span>
                <div className="flip-card__inner">
                    <div className="flip-card__front">
                        <div className="title">Log in</div>
                        <form className="flip-card__form" action="">
                            <input className="flip-card__input" value={info.loginEmail} name="email" placeholder="Email" type="email" onChange={(e) => setInfo({...info ,"loginEmail": e.target.value})}/>
                            <input className="flip-card__input" value={info.loginPassword}  name="password" placeholder="Password" type="password" onChange={(e) => setInfo({...info ,"loginPassword": e.target.value})}/>
                            <button className="flip-card__btn" type="button" onClick={() => login()}>Let`s go!</button>
                        </form>
                    </div>
                    <div className="flip-card__back">
                        <div className="title">Sign up</div>
                        <form className="flip-card__form" action="">
                            <input className="flip-card__input" value={info.registrationName} name="reg" placeholder="Name" type="name" onChange={(e) => setInfo({...info ,"registrationName": e.target.value})}/>
                            <input className="flip-card__input" value={info.registrationEmail} name="reg" placeholder="Email" type="email" onChange={(e) => setInfo({...info ,"registrationEmail": e.target.value})}/>
                            <input className="flip-card__input" value={info.registrationPassword} name="reg" placeholder="Password" type="password" onChange={(e) => setInfo({...info ,"registrationPassword": e.target.value})}/>
                            <button className="flip-card__btn" type="button" onClick={() => register()}>Confirm!</button>
                        </form>
                    </div>
                </div>
                </label>
            </div>   
        </div>
    )
}

export default Login