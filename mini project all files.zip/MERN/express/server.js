const express = require("express");
const cors = require("cors");
const app = express();
const mysql = require('mysql')

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: 'mysql',
    database: 'project'
  })

app.use(cors())
app.use(express.json())

var corsOptions = {
    origin: 'http://localhost:5173',
    optionsSuccessStatus: 200 // some legacy browsers (IE11, various SmartTVs) choke on 204
}

connection.connect();

app.post("/query", cors(corsOptions), (req, res) => {
    connection.query(`select ${req.body.require} as res from illiterate where District = '${req.body.district}' and Mandal = '${req.body.mandal}' and Muncipality = '${req.body.muncipality}' and WardName = '${req.body.wardname}'`, (err, rows, fields) => {
        if (err) throw err
        if(rows.length == 0)res.json({res : "Nill"})
        res.json({res : rows[0].res});
      })
})

app.post("/login", cors(corsOptions), (req, res) => {
    connection.query(`select * from loginInfo where email = '${req.body.email}' and password = '${req.body.password}'`, (err, rows1, fields) => {
        if (err) throw err
        if(rows1.length == 1){
          connection.query(`select district, mandal, muncipality, wardname from illiterate`, (err, rows, fields) => {
            if (err) throw err
            if(rows.length > 0){
              var result = {}
              rows.map(row => {
                var D = row.district
                var M = row.mandal
                var Mun = row.muncipality
                var W = row.wardname
                if(!(D in result)) result[D] = {}
                if(!(M in result[D])) result[D][M] = {}
                if(!(Mun in result[D][M])) result[D][M][Mun] = {}
                result[D][M][Mun][W] = 0;
              })
              res.json({login : true, data: result, name: rows1[0].name});
              return;
            }
          })
        }
        else res.json({login : false});
      })
})

app.post("/register", cors(corsOptions), (req, res) => {
    connection.query(`select count(*) as res from loginInfo where email = '${req.body.email}'`, (err, rows, fields) => {
        if (err) throw err
        if(rows[0].res >= 1) res.json({res: false});
        else{
            connection.query(`insert into loginInfo values('${req.body.name}','${req.body.email}', '${req.body.password}')`, (err, rows, fields) => {
                if (err) throw err
                if(rows.affectedRows == 1) res.json({res : true})
                else res.json({res: false})
              })
        }
      })
})

app.listen(3000)