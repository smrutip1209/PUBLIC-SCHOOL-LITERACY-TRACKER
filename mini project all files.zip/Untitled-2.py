
import pandas as pd
from sqlalchemy import create_engine

# MySQL database configuration
db_username = 'root'
db_password = 'mysql'
db_host = 'localhost'
db_port = '3306'
db_name = 'project'

# CSV file path
csv_file_path = "D:/mini project/illiterates.csv"

# Create a SQLAlchemy engine to connect to the MySQL database
engine = create_engine(f'mysql+mysqlconnector://{db_username}:{db_password}@{db_host}:{db_port}/{db_name}')

# Load CSV into a DataFrame
df = pd.read_csv(csv_file_path)

# Upload the DataFrame to the MySQL database
df.to_sql('illiterate', con=engine, if_exists='replace', index=False)
