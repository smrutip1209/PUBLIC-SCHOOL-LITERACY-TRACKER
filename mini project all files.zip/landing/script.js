// document.getElementById('district-form').addEventListener('submit', function(event) {
//     event.preventDefault();

//     var districts = parseInt(document.getElementById('districts').value);
//     var females = parseInt(document.getElementById('females').value);
//     var males = parseInt(document.getElementById('males').value);
//     var transgender = parseInt(document.getElementById('transgender').value);

//     // Your code to handle form submission goes here
//     console.log('Districts:', districts);
//     console.log('Females:', females);
//     console.log('Males:', males);
//     console.log('Transgender:', transgender);
// });

async function run(){
    var a = document.getElementsByName("district")[0].value
    var b = document.getElementsByName("mandal")[0].value
    var c = document.getElementsByName("municipality")[0].value
    var d = document.getElementsByName("wardname")[0].value
    var e = document.getElementsByName("gender")[0].value

    var res = await fetch(`http://localhost:3000/query/${a}/${b}/${c}/${d}/${e}`)

    console.log(res);

    // document.getElementsByClassName("result")[0].innerHTML = res.text()
}